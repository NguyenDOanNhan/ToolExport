import os
import container.variable as vs

def rename():
    path = vs.PATH_FILE_EXPORT
    files = os.listdir(path)
    for index1, file1 in enumerate(files):
        file_list = os.listdir(path + file1)
        for i in range(len(file_list)):
            if i == 0:
                file_name = os.listdir(path + file1 + '/' + file_list[i])
                os.rename(os.path.join(path + file1 + '/' + file_list[i], str(file_name[0])),
                          os.path.join(path + file1 + '/' + file_list[i], ''.join(['task', '.xls'])))
            if i == 1:
                file_bug = os.listdir(path + file1 + '/' + file_list[i])
                for bug in range(len(file_bug)):
                    if bug == 0:
                        name = 'bug_uat'
                        os.rename(os.path.join(path + file1 + '/' + file_list[i], str(file_bug[bug])),
                                  os.path.join(path + file1 + '/' + file_list[i], ''.join([name, '.xls'])))
                    if bug == 1:
                        name = 'bug_internal'
                        os.rename(os.path.join(path + file1 + '/' + file_list[i], str(file_bug[bug])),
                                  os.path.join(path + file1 + '/' + file_list[i], ''.join([name, '.xls'])))
