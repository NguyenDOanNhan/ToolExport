from datetime import date, timedelta
from selenium.webdriver.common.by import By
import time
import os
import container.variable as vs
from os.path import exists
import container.helper as hp


today = str(date.today())
subToday = str(date.today() - timedelta(days=7))


def export_data():
    def export_task(path):
        driver.get(path)
        time.sleep(2)
        WORK_PACKAGES = driver.find_element(By.ID, vs.ID_WORK_PACKAGE)
        WORK_PACKAGES.click()

        def filter_op():
            # FILTER
            time.sleep(2)
            button_filter = driver.find_element(By.ID, vs.ID_BUTTON_FILLTER)
            button_filter.click()

            time.sleep(2)
            filter_option_status = driver.find_element(By.ID, vs.ID_FILLTER_STATUS)
            filter_option_status.click()

            time.sleep(2)
            choose_status_all = driver.find_element(By.XPATH, vs.STATUS_OPTION_ALL)
            choose_status_all.click()

            time.sleep(2)
            add_filter_input = driver.find_element(By.XPATH, vs.INPUT_ADD_FILTER)
            add_filter_input.send_keys('type')

            time.sleep(2)
            add_filter_type = driver.find_element(By.XPATH, vs.FILTER_TYPE)
            add_filter_type.click()

            # click label type
            time.sleep(1)
            type_label = driver.find_element(By.XPATH, vs.LABEL_TYPE)
            type_label.click()

            time.sleep(1)
            driver.find_element(By.XPATH, vs.INPUT_FILTER_TYPE).send_keys('Task')

            time.sleep(1)
            choose_type_task = driver.find_element(By.XPATH, vs.OPTION_TYPE_TASK)
            choose_type_task.click()

        filter_op()

        def insert_column():
            # click btn setting
            time.sleep(1)
            driver.find_element(By.ID, vs.ID_WORK_PACKAGES_SETTING_BUTTON).click()

            time.sleep(1)
            setting_insert_column = driver.find_element(By.XPATH, vs.SETTING_INSERT_COLUMN)
            setting_insert_column.click()

            # add column accountable
            time.sleep(1)
            input_add_columns = driver.find_element(By.XPATH, vs.INPUT_ADD_COLUMN)
            input_add_columns.send_keys('Accountable')

            time.sleep(1)
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # add column spent time
            time.sleep(2)
            input_add_columns.send_keys('Spent time')
            choose_column_spent_time = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_spent_time.click()
            time.sleep(1)
            # submit
            button_apply_add_columns = driver.find_element(By.XPATH, vs.BUTTON_APPLY_ADD_COLUMN)
            button_apply_add_columns.click()

        insert_column()
        hp.export_data_excel_op(driver)
        time.sleep(2)

    def export_internal(path, sub_today):
        time.sleep(1)
        driver.get(path)
        time.sleep(2)
        WORK_PACKAGES = driver.find_element(By.ID, vs.ID_WORK_PACKAGE)
        WORK_PACKAGES.click()

        def filter_op():
            # FILTER
            time.sleep(2)
            button_filter = driver.find_element(By.ID, vs.ID_BUTTON_FILLTER)
            button_filter.click()

            time.sleep(2)
            filter_option_status = driver.find_element(By.ID, vs.ID_FILLTER_STATUS)
            filter_option_status.click()

            time.sleep(2)
            choose_status = driver.find_element(By.XPATH, vs.CHOOSE_STATUS_OPTION)
            choose_status.click()

            time.sleep(2)
            input_add_filter = driver.find_element(By.XPATH, vs.INPUT_ADD_FILTER)
            input_add_filter.send_keys('type')

            time.sleep(2)
            add_filler_type = driver.find_element(By.XPATH, vs.FILTER_TYPE)
            add_filler_type.click()

            time.sleep(2)
            driver.find_element(By.XPATH, vs.INPUT_STATUS_OPTION).send_keys('on')

            time.sleep(2)
            label_type = driver.find_element(By.XPATH, vs.LABEL_TYPE)

            time.sleep(2)
            choose_status_on_hold = driver.find_element(By.XPATH, vs.FILTER_TYPE)
            choose_status_on_hold.click()

            time.sleep(2)
            label_type.click()

            time.sleep(2)
            driver.find_element(By.XPATH, vs.INPUT_STATUS_OPTION_TWO).send_keys('rejected')

            time.sleep(2)
            choose_status_reject = driver.find_element(By.XPATH, vs.OPTION_TYPE_REJECT)
            choose_status_reject.click()

            time.sleep(1)
            label_type.click()

            time.sleep(1)
            input_add_filter.send_keys('Bug Cause')

            time.sleep(2)
            add_filler_bug_cause = driver.find_element(By.XPATH, vs.OPTION_TYPE_TASK)
            add_filler_bug_cause.click()

            time.sleep(2)
            driver.find_element(By.XPATH, vs.INPUT_FILTER_TYPE).send_keys('bug')

            time.sleep(2)
            choose_type_bug = driver.find_element(By.XPATH, vs.OPTION_TYPE_BUG)
            choose_type_bug.click()

            time.sleep(1)
            # option_bug_cause
            driver.find_element(By.XPATH, vs.OPTION_BUG_CAUSE).click()
            time.sleep(1)
            # choose_bug_cause_is_not
            driver.find_element(By.XPATH, vs.BUG_CAUSE_IS_NOT).click()
            time.sleep(1)
            # input_bug_cause_is_not
            driver.find_element(By.XPATH, vs.INPUT_BUG_CAUSE_IS_NOT).click()
            time.sleep(1)
            # choose_bug_cause_spec
            driver.find_element(By.XPATH, vs.FILTER_TYPE).click()
            time.sleep(1)
            label_type.click()

            time.sleep(1)
            input_add_filter.send_keys('Created on')
            time.sleep(1)
            # add_filler_created_on
            driver.find_element(By.XPATH, vs.OPTION_TYPE_TASK).click()
            time.sleep(1)
            # option_created_on
            driver.find_element(By.ID, vs.ID_CREATED_ON).click()
            time.sleep(1)
            # choose_created_on_between
            driver.find_element(By.XPATH, vs.CREATED_ON_BETWEEN).click()
            time.sleep(1)
            # created_on_between_start
            driver.find_element(By.ID, vs.ID_BETWEEN_START).send_keys(sub_today)
            time.sleep(1)
            # created_on_between_end
            driver.find_element(By.ID, vs.ID_BETWEEN_END).send_keys(today)

        filter_op()

        def insertColumns():
            time.sleep(2)
            work_packages_settings_button = driver.find_element(By.ID, vs.ID_WORK_PACKAGES_SETTING_BUTTON)
            work_packages_settings_button.click()

            # setting_insert_column
            time.sleep(2)
            driver.find_element(By.XPATH, vs.SETTING_INSERT_COLUMN).click()

            time.sleep(2)
            delete_option_version = driver.find_element(By.XPATH, vs.REMOVE_CONFIGURATION)
            delete_option_version.click()

            time.sleep(2)
            delete_option_assignee = driver.find_element(By.XPATH, vs.OPTION_ASSIGNEE)
            delete_option_assignee.click()

            time.sleep(2)
            delete_option_status = driver.find_element(By.XPATH, vs.OPTION_STATUS)
            delete_option_status.click()

            time.sleep(2)
            input_add_column = driver.find_element(By.XPATH, vs.INPUT_ADD_COLUMN)
            input_add_column.send_keys('Category')
            # add_column_category
            time.sleep(1)
            driver.find_element(By.XPATH, vs.OPTION_TYPE_TASK).click()

            # add_column_status
            time.sleep(2)
            input_add_column.send_keys('Status')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_assignee
            time.sleep(2)
            input_add_column.send_keys('Assignee')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_author
            time.sleep(2)
            input_add_column.send_keys('Author')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_Bug_severity
            time.sleep(2)
            input_add_column.send_keys('Bug Severity')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_Bug_type
            time.sleep(2)
            input_add_column.send_keys('Bug Type')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_Bug_cause
            time.sleep(2)
            input_add_column.send_keys('Bug Cause')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_Bug_Ui
            time.sleep(2)
            input_add_column.send_keys('Bug Ui')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_created_on
            time.sleep(2)
            input_add_column.send_keys('Created on')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_Accountable
            time.sleep(2)
            input_add_column.send_keys('Accountable')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_UAT
            time.sleep(2)
            input_add_column.send_keys('UAT')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_updated_on
            time.sleep(2)
            input_add_column.send_keys('Updated on')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_version
            time.sleep(2)
            input_add_column.send_keys('Version')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # add_column_spent_time
            time.sleep(2)
            input_add_column.send_keys('Spent time')
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # btn_apply
            time.sleep(2)
            driver.find_element(By.XPATH, vs.BUTTON_APPLY_ADD_COLUMN).click()

        insertColumns()
        hp.export_data_excel_op(driver)

    def export_uat(path, sub_today):
        time.sleep(2)
        driver.get(path)
        time.sleep(2)
        WORK_PACKAGES = driver.find_element(By.ID, vs.ID_WORK_PACKAGE)
        WORK_PACKAGES.click()

        def filter_op():
            # FILTER
            time.sleep(2)
            button_filter = driver.find_element(By.ID, vs.ID_BUTTON_FILLTER)
            button_filter.click()

            time.sleep(2)
            filter_option_status = driver.find_element(By.ID, vs.ID_FILLTER_STATUS)
            filter_option_status.click()

            # Status
            time.sleep(2)
            choose_status_all = driver.find_element(By.XPATH, vs.STATUS_OPTION_IS_NOT)
            choose_status_all.click()

            time.sleep(2)
            input_status_is_not = driver.find_element(By.XPATH, vs.INPUT_STATUS)
            input_status_is_not.send_keys('rejected')

            time.sleep(2)
            add_rejected_input_status = driver.find_element(By.XPATH, vs.OPTION_ONE)
            add_rejected_input_status.click()

            time.sleep(2)
            input_status_is_not.send_keys('on')
            add_on_hold_input_status = driver.find_element(By.XPATH, vs.ON_HOLD_INPUT_STATUS)
            add_on_hold_input_status.click()

            # Add Filter Type
            time.sleep(2)
            add_filter_input = driver.find_element(By.XPATH, vs.INPUT_ADD_FILTER)
            add_filter_input.send_keys('type')
            add_filter_input.click()

            # bug UAT
            time.sleep(2)
            add_filter_type = driver.find_element(By.XPATH, vs.FILTER_TYPE)
            add_filter_type.click()

            time.sleep(1)
            type_label = driver.find_element(By.XPATH, vs.LABEL_TYPE)
            type_label.click()

            time.sleep(1)
            driver.find_element(By.XPATH, vs.INPUT_FILTER_TYPE).send_keys('Bug UAT')
            choose_type_bug_uat = driver.find_element(By.XPATH, vs.OPTION_ONE)
            choose_type_bug_uat.click()

            # Add Filter UAT Type
            time.sleep(2)
            add_filter_uat_type = driver.find_element(By.XPATH, vs.INPUT_ADD_UAT_TYPE)
            add_filter_uat_type.send_keys('UAT')
            add_filter_uat_type.click()

            time.sleep(2)
            choose_uat_type = driver.find_element(By.XPATH, vs.OPTION_ONE)
            choose_uat_type.click()

            time.sleep(2)
            choose_status_is_not = driver.find_element(By.XPATH, vs.STATUS_OPTION_IS_NOT_UAT_TYPE)
            choose_status_is_not.click()

            time.sleep(2)
            input_add_uat_type = driver.find_element(By.XPATH, vs.INPUT_UAT_TYPE)
            input_add_uat_type.send_keys('CR')

            time.sleep(1)
            add_uat_type_cr = driver.find_element(By.XPATH, vs.OPTION_ONE)
            add_uat_type_cr.click()

            input_add_uat_type.send_keys('not')
            add_uat_type_not_bug = driver.find_element(By.XPATH, vs.OPTION_ONE)
            add_uat_type_not_bug.click()

            # Add Filter CREATED ON
            time.sleep(2)
            add_filter_created_one = driver.find_element(By.XPATH, vs.CREATED_ON)
            add_filter_created_one.send_keys('Created')
            add_filter_created_one.click()

            time.sleep(2)
            choose_created_one = driver.find_element(By.XPATH, vs.OPTION_ONE)
            choose_created_one.click()

            time.sleep(2)
            choose_status_created_on = driver.find_element(By.XPATH, vs.STATUS_OPTION_CREATED_ON)
            choose_status_created_on.click()
            time.sleep(1)
            # created_on_between_start
            driver.find_element(By.ID, vs.ID_BETWEEN_START).send_keys(sub_today)
            # created_on_between_end
            driver.find_element(By.ID, vs.ID_BETWEEN_END).send_keys(today)

        filter_op()
        work_packages_setting_button = driver.find_element(By.ID, vs.ID_WORK_PACKAGES_SETTING_BUTTON)

        def insert_title_column():
            # click btn setting
            time.sleep(2)
            work_packages_setting_button.click()
            setting_insert_column = driver.find_element(By.XPATH, vs.SETTING_INSERT_COLUMN)
            setting_insert_column.click()
            # REMOVE VERSION
            time.sleep(2)
            remove_version = driver.find_element(By.XPATH, vs.REMOVE_CONFIGURATION)
            remove_version.click()
            input_add_columns = driver.find_element(By.XPATH, vs.INPUT_ADD_COLUMN)

            time.sleep(2)
            delete_option_assignee = driver.find_element(By.XPATH, vs.OPTION_ASSIGNEE)
            delete_option_assignee.click()
            time.sleep(2)
            delete_option_status = driver.find_element(By.XPATH, vs.OPTION_STATUS)
            delete_option_status.click()

            time.sleep(2)
            input_add_columns.send_keys('Category')
            choose_column_category = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_category.click()

            time.sleep(2)
            input_add_columns.send_keys('Status')
            # add_column_status
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            time.sleep(2)
            input_add_columns.send_keys('Assignee')
            # add_column_assignee
            driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST).click()

            # Add Attribute Author
            time.sleep(2)
            input_add_columns.send_keys('Author')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Bug Severity
            time.sleep(2)
            input_add_columns.send_keys('Bug Severity')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Bug Type
            time.sleep(2)
            input_add_columns.send_keys('Bug Type')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Bug Cause
            time.sleep(2)
            input_add_columns.send_keys('Bug Cause')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Bug UI-Logic
            time.sleep(2)
            input_add_columns.send_keys('Bug UI-Logic')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Created on
            time.sleep(2)
            input_add_columns.send_keys('Created on')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Accountable
            time.sleep(2)
            input_add_columns.send_keys('Accountable')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute UAT Type
            time.sleep(2)
            input_add_columns.send_keys('UAT Type')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Updated on
            time.sleep(2)
            input_add_columns.send_keys('Updated on')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Version
            time.sleep(2)
            input_add_columns.send_keys('Version')
            choose_column_accountable = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_accountable.click()

            # Add Attribute Spent time
            time.sleep(2)
            input_add_columns.send_keys('Spent time')
            choose_column_spent_time = driver.find_element(By.XPATH, vs.COLUMN_DEFAULT_FIRST)
            choose_column_spent_time.click()

            # submit
            button_apply_add_columns = driver.find_element(By.XPATH, vs.BUTTON_APPLY_ADD_COLUMN)
            button_apply_add_columns.click()

        insert_title_column()
        hp.export_data_excel_op(driver)
        time.sleep(2)

    get_input = hp.getInput()
    listNameProject = get_input[0]
    listLinkProject = get_input[1]

    for i in range(len(listLinkProject)):
        file_exists = exists(vs.PATH_FILE_EXPORT + listNameProject[i])
        if not file_exists:
            os.mkdir(vs.PATH_FILE_EXPORT + listNameProject[i])
            os.mkdir(vs.PATH_FILE_EXPORT + listNameProject[i] + '/task')
            os.mkdir(vs.PATH_FILE_EXPORT + listNameProject[i] + '/bug')

        driver = hp.get_driver(listNameProject[i], '/task')
        time.sleep(1)
        hp.login(vs.LOGIN_OP, driver)
        time.sleep(2)
        export_task(listLinkProject[i])
        time.sleep(2)
        driver = hp.get_driver(listNameProject[i], '/bug')
        hp.login(vs.LOGIN_OP, driver)
        export_internal(listLinkProject[i], subToday)
        time.sleep(2)
        export_uat(listLinkProject[i], subToday)
        time.sleep(2)
